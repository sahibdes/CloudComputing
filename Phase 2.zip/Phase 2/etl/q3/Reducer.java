package Testing.sahib;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
//import java.sql.Connection;
//import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
//import java.util.HashMap;

import com.google.gson.JsonSyntaxException;

//import com.mysql.jdbc.Statement;

public class Reducer {
	// final static String jdbcUrl = "jdbc:mysql://" + "localhost" + ":" +
	// "3306"
	// + "/" + "CloudTest" + "?user=" + "root" + "&password="
	// + "Q3tech123";
	// static HashMap<String, String> hmap = new HashMap<String, String>();

	public static void main(String[] args) throws JsonSyntaxException,
			ParseException, IOException, SQLException {
		BufferedReader bfr = new BufferedReader(
				new InputStreamReader(System.in));
		// Connection con = null;

		// con = DriverManager.getConnection(jdbcUrl, "root", "Q3tech123");
		String str = "";
		while ((str = bfr.readLine()) != null) {
			// basically every tweet will have a column for +-* relationship.
			// lets do this shit
			// String val = "";
			String[] splitvals = str.split("\t");
			// check for + relation
			// String plusVal = "";
			// String key = "";
			// String astVal = "";
			// String minusVal = "";
			// for (Entry<String, String> entry : hmap.entrySet()) {
			// if (entry.getValue().equals(splitvals[0])) {
			// key = entry.getKey();
			// // +relation
			// if (!hmap.get(splitvals[0]).equals(key)) {
			// plusVal = hmap.get(splitvals[0]);
			// // *relation
			// } else if (hmap.get(splitvals[0]).equals(key)) {
			// astVal = hmap.get(splitvals[0]);
			// }
			// }
			// if (entry.getKey().equals(splitvals[1])) {
			// if (!entry.getValue().equals(splitvals[0])) {
			// minusVal = hmap.get(splitvals[0]);
			// }
			// }
			// }
			// if (hmap.containsKey(splitvals[0])) {
			// val = hmap.get(splitvals[0]) + "&&" + splitvals[1];
			// } else
			// val = splitvals[1];
			//
			// hmap.put(splitvals[0], val);
			// }

			// Statement st = (Statement) con.createStatement();

			// String sql = "INSERT INTO retweet_db (tweet_user, retweet_user)"
			// + "VALUES (" + "'" + splitvals[0] + "'" + "," + "'"
			// + splitvals[1] + "'" + ")";
			// st.execute(sql);
			System.out.println(splitvals[0] + "\t" + splitvals[1]);
		}
		// con.close();

	}
}
