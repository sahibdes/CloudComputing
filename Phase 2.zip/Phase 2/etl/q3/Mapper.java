package Testing.sahib;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

public class Mapper {
	public static void main(String[] args) throws JsonSyntaxException,
			ParseException, IOException {
		BufferedReader bfr1 = new BufferedReader(new InputStreamReader(
				System.in));
		String tweet = "";
		while ((tweet = bfr1.readLine()) != null) {
			String output = jsonToString(tweet);
			if (!output.isEmpty())
				System.out.println(output);
		}
	}

	private static String jsonToString(String tweet) throws ParseException,
			JsonSyntaxException, IOException {
		String output = "";
		if (!tweet.isEmpty()) {
			Gson gs = new Gson();
			JsonParser parser = new JsonParser();
			JsonObject js_main = parser.parse(tweet).getAsJsonObject();
			JsonObject js_user = js_main.get("user").getAsJsonObject();

			if (js_main.has("retweeted_status")) {
				JsonObject js_retweet = js_main.get("retweeted_status")
						.getAsJsonObject();
				JsonObject js_retweet_user = js_retweet.get("user")
						.getAsJsonObject();
				output = js_user.get("id_str").getAsString() + "\t"
						+ js_retweet_user.get("id_str").getAsString();
			}
		}
		return output;
	}
}
