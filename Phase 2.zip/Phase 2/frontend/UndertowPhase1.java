import java.math.BigInteger;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Deque;
import java.util.Map;
import java.util.TreeMap;

import io.undertow.Undertow;
import io.undertow.io.Sender;
import io.undertow.server.*;
import io.undertow.util.Headers;

public class UndertowPhase1 {

	final static String jdbcUrl = "jdbc:mysql://" + "ec2-52-5-29-198.compute-1.amazonaws.com"
			+ ":3306/hashtagdb";
	static Connection con = null;
	public static void main(String[] args) {
		Undertow server = Undertow.builder().addHttpListener(8080, "0.0.0.0")
				.setHandler(new HttpHandler() {

					@SuppressWarnings("deprecation")
					public void handleRequest(final HttpServerExchange exchange)
							throws Exception {
						
						Sender sender = exchange.getResponseSender();

						exchange.getResponseHeaders().put(Headers.CONTENT_TYPE,
								"text/plain");

						if (exchange.getRequestPath().contains("q1")) {
							Map<String, Deque<String>> params = exchange
									.getQueryParameters();
							BigInteger keyInt = new BigInteger(params
									.get("key").getFirst());
							BigInteger X = new BigInteger(
									"8271997208960872478735181815578166723519929177896558845922250595511921395049126920528021164569045773");

							BigInteger Y = keyInt.divide(X);
							String spiralized_cipher = spiralize(params.get(
									"message").getFirst());
							BigInteger twentyFive = new BigInteger("25");
							BigInteger one = new BigInteger("1");

							BigInteger Z = one.add((Y.mod(twentyFive)));
							String teamID = "MadHatters";

							String awsID1 = "2404-3085-8626 ";
							String awsID2 = "1166-8424-3822 ";
							String awsID3 = "1234-1234-1234";

							java.util.Date dateTime = new java.util.Date();
							String message = caesarify(Z, spiralized_cipher);

							StringBuilder sb = new StringBuilder();
							sb.append(teamID)
									.append(",")
									.append(awsID1)
									.append(",")
									.append(awsID2)
									.append(",")
									.append(awsID3)
									.append("\n")
									.append(new SimpleDateFormat(
											"yyyy-MM-dd HH:mm:ss")
											.format(new java.util.Date()))
									.append("\n").append(message).append("\n");

							exchange.getResponseSender().send(sb.toString());
						} else if (exchange.getRequestPath().contains("q4")) {

							Class.forName("com.mysql.jdbc.Driver");
							
							con = DriverManager.getConnection(jdbcUrl, "user",
									"password");
							// con =
							// DataConnector.getInstance().getConnection();
							Map<String, Deque<String>> params = exchange
									.getQueryParameters();
							Collection<Deque<String>> paramDeq = params
									.values();

							String hashtag = params.get("hashtag").getFirst();
							String startDate = params.get("start").getFirst();
							String endDate = params.get("end").getFirst();
							System.out.println(hashtag + startDate + endDate);

							Date fromDate = Date.valueOf(startDate);
							Date toDate = Date.valueOf(endDate);
							// GET
							// /q4?hashtag=SamSmith&start=2014-03-26&end=2014-03-30

							String sqlCmd = "select tweet_info from hashtagdb.popularhashtag where binary(hashtag) regexp '^("+hashtag+")$'";

							System.out.println(sqlCmd);
							PreparedStatement ps = con
									.prepareStatement(sqlCmd);
							
							ResultSet rs = ps.executeQuery();
							StringBuilder output = new StringBuilder();
							TreeMap<Long, String> tmap = new TreeMap<Long, String>();

							output.append("MadHatters,")
									.append("1166-8424-3822,")
									.append("2404-3085-8626,")
									.append("1234-5678-1234").append("\n");

							while (rs.next()) {

								String[] tweets = rs.getString("tweet_info")
										.split("\\$");

								for (int i = 0; i < tweets.length; i++) {

									String[] userinfo = tweets[i].split("\\&");

									String[] dateSplit = userinfo[2]
											.split("\\+");
									Date toCheck = Date.valueOf(dateSplit[0]);
									if ((toCheck.equals(fromDate) || toCheck
											.equals(toDate))
											|| (toCheck.after(fromDate) && toCheck
													.before(toDate))) {
										tmap.put(Long.valueOf(userinfo[1]),
												userinfo[0] + "," + userinfo[2]
														+ "\n");

									}
								}
								for (java.util.Map.Entry<Long, String> entry : tmap
										.entrySet()) {
									output.append(entry.getKey()).append(",")
											.append(entry.getValue());
								}
							}
							rs.close();

							sender.send(output.toString());
							output = new StringBuilder();
						}
					}
				}).build();
		server.start();

	}

	public static String caesarify(BigInteger Z, String spiralized_cipher) {

		String s = spiralized_cipher;
		int k = Z.intValue();
		StringBuffer decoded = new StringBuffer();

		for (int i = 0; i < s.length(); i++) {
			int x = (((int) s.charAt(i))) - k;
			if (x < 65) {
				x += 26;
			}

			decoded.append((char) (x));
		}
		return decoded.toString();
	}

	public static String spiralize(String s) {

		int len = s.length();
		int m = (int) Math.sqrt(len);
		int n = (int) Math.sqrt(len);
		StringBuffer Cipher_2D = new StringBuffer();
		char a[][] = new char[m][n];

		int index = 0;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				a[i][j] = s.charAt(index);
				index++;
			}
		}

		int t = 0, b = m - 1, l = 0, r = n - 1;
		int dir = 0;

		while (t <= b && l <= r) {
			if (dir == 0) {
				for (int i = l; i <= r; i++) {
					// System.out.print(a[t][i] + " ");
					Cipher_2D.append(a[t][i]);
				}
				t++;
			}

			else if (dir == 1) {
				for (int i = t; i <= b; i++) {
					// System.out.print(a[i][r]+ " ");
					Cipher_2D.append(a[i][r]);
				}
				r--;
			}

			else if (dir == 2) {
				for (int i = r; i >= l; i--) {
					// System.out.print(a[b][i]+ " ");
					Cipher_2D.append(a[b][i]);
				}
				b--;
			} else if (dir == 3) {
				for (int i = b; i >= t; i--) {
					// System.out.print(a[i][l]+ " ");
					Cipher_2D.append(a[i][l]);
				}
				l++;
				dir = 3;
			}
			dir = (dir + 1) % 4;
		}
		return (Cipher_2D.toString());
	}
}